<?php
	 $static_page = array(
	 	"Home"=>"home",
	 	"Aims & Scope"=>"aims-scope",
	 	"Editorial Board"=>"editorial-board",
	 	"Instructions to Author" => "instructions-to-author",
	 	"Manuscript Work Flow" => "manuscript-work-flow",
	 	"Current Issue" => "current-issue",
	 	"Special Issues" => "special-issues",
	 	"Article in Press" => "article-in-press",
	 	"Archive" => "archive"
	 	);
?>
