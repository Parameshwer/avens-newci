<div>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2949.655737587822!2d-71.616576!3d42.328540999999994!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e3f5011f378b69%3A0xbdbb85911a05ce7c!2s47+Hemlock+Dr%2C+Northborough%2C+MA+01532%2C+USA!5e0!3m2!1sen!2sin!4v1428146554517" width="1350" height="400" frameborder="0" style="border:0"></iframe>
</div>
<div class="hentry">
<div class="container">
<div class="row" id="contact-page">
<div class="col-sm-8">
<div class="container-inner">
	<div><h1>Contact</h1></div>
	<div class="row">
		<div class="col-sm-6">
			<h2>Avens Publishing Group LLC</h2>
			<ul>			
			<li>47 Hemlock Dr,  Northborough</li>
			<li>MA 01532,USA</li>
			</ul>
		</div>
		<div class="col-sm-6">
			<h2>Avens Publishing Group</h2>
			<ul>
			<li>502 Jyothiraditya, Srinagar Colony</li>
			<li>Hyderabad, India</li>
			</ul>
		</div>
	</div><br>
	<div class="row">
		<div class="col-sm-12 contact-email">Email:&nbsp;<a href="mailto:contact@avensonline.org">contact@avensonline.org</a></div>
	</div><br>
	<div class="row">
	<form name="form" id="form" method="post" class="contact-form" onsubmit="return valid13();" novalidate="novalidate">
		<div class="form-group">
			<div class="col-sm-5"><input type="text" class="form-control" id="first_name" name="first_name" placeholder="Name"></div>
			<label class="errorfield1" id="errorfiled"></label>
		</div>
		<div class="form-group">
			<div class="col-sm-7"><input type="text" class="form-control" id="email_id" name="email_id" placeholder="Email"></div><div class="col-sm-4"></div>
			<label class="errorfield2" id="errorfiled"></label>
		</div>
		<div class="form-group">
			<div class="col-sm-5"><input type="text" class="form-control" name="phone" id="phone_no" placeholder="Phone"></div><div class="col-sm-4"></div>
			<label class="errorfield3" id="errorfiled"></label>
		</div>
		<div class="form-group">
			<div class="col-sm-7">
				<textarea class="form-control" name="mess_age" id="mess_age" placeholder="Your Message here"></textarea>
				<label class="errorfield4" id="errorfiled"></label>
			</div>
		</div>
		<div class="form-group">
			<div class="col-sm-12">
				<input id="submit" class="btn btn-success" name="submit" type="submit" value="Submit">
			</div>
		</div>
	</form>
	</div>
</div>
</div>
<div class="col-sm-4">
	<div id="tertiary" class="sidebar-container" role="complementary">
		<div class="sidebar-inner">
			<div class="widget-area">
				<aside id="text-4" class="widget widget_text">			<div class="textwidget"><div class="fb-like-box fb_iframe_widget" data-href="https://www.facebook.com/www.avensonline.org" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true" data-width="260" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=562268420549512&amp;color_scheme=light&amp;container_width=257&amp;header=true&amp;href=https%3A%2F%2Fwww.facebook.com%2Fwww.avensonline.org&amp;locale=en_US&amp;sdk=joey&amp;show_border=true&amp;show_faces=true&amp;stream=false&amp;width=260"><span style="vertical-align: bottom; width: 260px; height: 213px;"><iframe name="f3a98f8e3d68d54" width="260px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:like_box Facebook Social Plugin" src="https://www.facebook.com/v2.0/plugins/like_box.php?app_id=562268420549512&amp;channel=http%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D42%23cb%3Df364eeb0460ae38%26domain%3Dwww.avensonline.org%26origin%3Dhttp%253A%252F%252Fwww.avensonline.org%252Ff23e0272d079358%26relation%3Dparent.parent&amp;color_scheme=light&amp;container_width=257&amp;header=true&amp;href=https%3A%2F%2Fwww.facebook.com%2Fwww.avensonline.org&amp;locale=en_US&amp;sdk=joey&amp;show_border=true&amp;show_faces=true&amp;stream=false&amp;width=260" style="border: none; visibility: visible; width: 260px; height: 213px;" class=""></iframe></span></div></div>
		</aside>			</div><!-- .widget-area -->
		</div><!-- .sidebar-inner -->
	</div><!-- #tertiary -->
</div>
</div>
</div>
</div>