<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
<title>Avens Publishing Login</title>
<link rel="stylesheet" href="<?php echo base_url();?>public/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/signin.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/admin_style.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/textAngular.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/font-awesome.min.css">
<!-- <link rel="stylesheet" href="<?php echo base_url();?>public/css/editor-style.css"> -->
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,600,600italic' rel='stylesheet' type='text/css'>
</head>