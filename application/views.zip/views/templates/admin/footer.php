<script src="<?php echo base_url();?>public/js/jquery.min.js"></script> 
<script src="http://cdn.tinymce.com/4/tinymce.min.js"></script>
<script src="<?php echo base_url();?>public/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>public/js/angular.min.js"></script>
<script src="<?php echo base_url();?>public/js/angular-route.min.js"></script>

<script src="<?php echo base_url();?>public/js/tinymice/tinymce.js"></script>
<script src="<?php echo base_url();?>public/js/tinymice/tinymce_angular.js"></script>
<script src="<?php echo base_url();?>public/js/angular-route.min.js"></script>
<script src="<?php echo base_url();?>public/js/ng-file-upload-shim.js"></script>
<script src="<?php echo base_url();?>public/js/ng-file-upload.js"></script>
<script src="<?php echo base_url();?>angularjs/AngularFormApp.js"></script>
<script src="<?php echo base_url(); ?>public/js/textAngular-rangy.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>public/js/textAngular-sanitize.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>public/js/textAngular.min.js" type="text/javascript"></script> 

</body>
</html>